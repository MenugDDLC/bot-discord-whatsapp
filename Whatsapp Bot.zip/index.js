// index.js - Punto de entrada del bot
// Este archivo simplemente inicia el bot principal

console.log('🚀 Iniciando WhatsApp-Discord Bridge Bot...');
console.log('📁 Cargando bot.js...\n');

// Cargar y ejecutar el bot principal
require('./bot.js');
